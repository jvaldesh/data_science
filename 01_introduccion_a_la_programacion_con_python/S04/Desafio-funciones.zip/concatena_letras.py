import string

def gen(n):
    return string.ascii_lowercase[:n]