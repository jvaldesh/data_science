n = int(input("Ingrese un número\n"))

for i in range(n+1):
    if i % 2 == 0:
        print(i)