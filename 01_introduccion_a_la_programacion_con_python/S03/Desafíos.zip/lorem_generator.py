import sys

n = int(sys.argv[1])

texto = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed efficitur elit. In hac habitasse platea dictumst. Duis congue blandit porta. Suspendisse sed nunc id dui facilisis aliquet id quis purus. Aliquam venenatis faucibus elementum. Etiam nisl erat, lacinia a tempus ac, auctor nec ante. Donec varius ipsum sed nisl auctor, a laoreet nibh interdum. Vivamus hendrerit lorem nec felis commodo molestie. Suspendisse consectetur, augue sit amet blandit malesuada, tortor neque porttitor nunc, non pretium leo metus in nisl. Integer commodo euismod sem quis ultrices. Nullam id ex tempus, suscipit tortor vel, pellentesque lectus. Quisque rutrum consequat nisl, a dapibus magna molestie sit amet. Duis dignissim lacus ante, feugiat dapibus tortor dapibus sed. Integer vel eleifend nisl, at congue diam. Donec quis venenatis mauris."

for i in range(n):
    print(texto)
