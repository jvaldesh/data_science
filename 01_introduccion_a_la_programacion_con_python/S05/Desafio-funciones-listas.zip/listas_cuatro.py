import listas_uno as lu
import velocidad as vc

for auto in lu.autos:
    if auto[3] is True:
        print(auto[0])